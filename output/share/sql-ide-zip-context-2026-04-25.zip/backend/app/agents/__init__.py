"""Agent pipeline implementations."""
