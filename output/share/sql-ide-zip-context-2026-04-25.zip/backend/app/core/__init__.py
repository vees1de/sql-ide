"""Core settings and helpers."""
